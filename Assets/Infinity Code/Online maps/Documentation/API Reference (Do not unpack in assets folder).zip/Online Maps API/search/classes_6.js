var searchData=
[
  ['geocodedwaypoint_1406',['GeocodedWaypoint',['../classOnlineMapsGoogleDirectionsResult_1_1GeocodedWaypoint.html',1,'OnlineMapsGoogleDirectionsResult']]],
  ['geocodingparams_1407',['GeocodingParams',['../classOnlineMapsOpenRouteService_1_1GeocodingParams.html',1,'OnlineMapsOpenRouteService.GeocodingParams'],['../classOnlineMapsGoogleGeocoding_1_1GeocodingParams.html',1,'OnlineMapsGoogleGeocoding.GeocodingParams']]],
  ['geometry_1408',['Geometry',['../classOnlineMapsOpenRouteServiceGeocodingResult_1_1Geometry.html',1,'OnlineMapsOpenRouteServiceGeocodingResult']]]
];
